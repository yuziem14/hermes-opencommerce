/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./resources/js/tagSelector.js":
/*!*************************************!*\
  !*** ./resources/js/tagSelector.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var tagSelector = document.querySelector('select#tags');
var tagsContainer = document.querySelector('.selected-tags');
var selectedTags = document.querySelectorAll('.selected-tags .tag');

function getTagMarkup(text, value) {
  return "\n    <input type=\"hidden\" name=\"tags[]\" value=\"".concat(value, "\">\n    <p>").concat(text, "</p>\n    <img src=\"/images/close.svg\" alt=\"Unselect\"/>\n  ").trim();
}

function isTagSelected(value) {
  tagInputs = document.querySelectorAll("input[name=\"tags[]\"][value=\"".concat(value, "\"]"));
  return tagInputs.length !== 0;
}

function handleTagSelectorChange(event) {
  var _event$target = event.target,
      value = _event$target.value,
      options = _event$target.options;
  var text = options[options.selectedIndex].text;

  if (!isTagSelected(value)) {
    var newTag = document.createElement('div');
    newTag.classList.add('tag');
    newTag.innerHTML = getTagMarkup(text, value);
    newTag.addEventListener('click', handleOnTagClick);
    tagsContainer.append(newTag);
  }

  tagSelector.value = '';
}

function handleOnTagClick(event) {
  var target = event.target;
  tagsContainer.removeChild(target);
}

tagSelector.addEventListener('change', handleTagSelectorChange);
selectedTags.forEach(function (tagElement) {
  tagElement.addEventListener('click', handleOnTagClick);
});

/***/ }),

/***/ 3:
/*!*******************************************!*\
  !*** multi ./resources/js/tagSelector.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\yuri_\Home\Code\Web\Frameworks\Laravel-PHP\hermes-opencommerce\src\resources\js\tagSelector.js */"./resources/js/tagSelector.js");


/***/ })

/******/ });